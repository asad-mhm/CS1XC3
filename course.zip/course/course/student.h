/**
Student: typedef struct of a student, including first and last name, ID, grades, and the number of graades
*/ 
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/**
add_grade: takes a pointer to a student and a grade double and adds that grade to the student's grades and adds 1 to the number of grades
*/
void add_grade(Student *student, double grade);
/**
average: Takes a pointer to a student and returns the average of all the grades as a double
*/
double average(Student *student);
/**
print_student: takes a pointer to a student and prints out all the information about a student
*/
void print_student(Student *student);
/**
generate_random_student: takes an integer and returns a randomly generated student with random grades totalling to the given integer
*/
Student* generate_random_student(int grades); 
