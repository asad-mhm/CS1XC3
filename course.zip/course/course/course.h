#include "student.h"
#include <stdbool.h>
/**
Course: typedef struct used to store course information such as course name, code, students, and number of students
*/
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
enroll_student: takes a Course and a student pointer and adds that student to the course, no return value
*/
void enroll_student(Course *course, Student *student);
/**
print_course: takes a course and prints the name, code, total students, and student info of a course
*/
void print_course(Course *course);
/**
top_student: takes a course and returns student with the highest average 
*/
Student *top_student(Course* course);
/**
passing: takes a course and a pointer to an integer and sets that integer to the total number of passing students in the course and returns all the passing students
*/
Student *passing(Course* course, int *total_passing);


