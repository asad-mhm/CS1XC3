#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); // calloc is used to initially add the first student to the class
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); //realloc is used to reallocate memory for each student added after the first one
  }
  course->students[course->total_students - 1] = *student;  //adds student to course
}

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) //loop iterates through students in a course and prints out their info
    print_student(&course->students[i]);
}

Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL; //if a course has no students, top_students returns NULL
 
  double student_average = 0;
  double max_average = average(&course->students[0]); //max average initially set to be that of the first students' average
  Student *student = &course->students[0]; //keeps track of student with max_average
 
  for (int i = 1; i < course->total_students; i++)//loops through all students in class except first one as that student was initially assigned to max_average
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) //iterates through students in the course and adds to counter if their average is >= 50
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student)); //sets memory of list of students that are passing to counter that tracked passing students

  int j = 0;
  for (int i = 0; i < course->total_students; i++) // loops through students in course and adds them to list of passing students if they are passing
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}